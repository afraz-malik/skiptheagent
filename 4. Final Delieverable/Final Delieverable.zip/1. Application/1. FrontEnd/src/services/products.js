export const products = [
  {
    id: 'xdsl2kldsfj',
    city: 'Lahore',
    car_info: '2019 Fiat 124 Spider',
    model: '2019',
    mileage_km: '20',
    photos: [],
    description: `This is the Photoshop's version of Lorem Ipsum. Proin gravida nibh
    vel velit auctor aliqut. Aenea solicitun, lorem qus bibendum
    autos, nisi elit consquatl ipsum.Proin gravida nibh vel velit
    auctor aliqut. Aenea solicitun, lorem qus bibendum autos, nisi
    elit consquatl ipsum .Proin gravida nibh vel velit auctor aliqut.
    Aenea solicitun, lorem qus bibendum autos, nisi elit consquatl
    ipsum .Proin gravida nibh vel velit auctor aliqut. Aenea
    solicitun, lorem qus bibendum autos, nisi elit consquatl ipsum
    .Proin gravida nibh vel velit auctor aliqut. Aenea solicitun,
    lorem qus bibendum autos, nisi elit consquatl ipsum`,
    last_updated: 24,
    selling: {
      transation_type: 'Cash',
      price: '355',
    },
    details: {
      exterior_color: 'Whtie',
      reg_city: 'Lahore',
      engine_type: 'Any',
      engine_capacity: '343',
      transmission: 'Automatic',
      assembly: '34',
      body_type: 'Coupe',
      make: 'Fiat',
    },
    features: {
      abs: true,
      airbags: true,
      am_fm: true,
      ac: true,
      power_mirrors: true,
      power_steering: true,
      cd_player: true,
      cassete: true,
      immobilizer: true,
      power_locks: true,
      nav_system: true,
    },
    contact_info: {
      phone: '+92 324 8205435',
      secondar_phone: '+92 324 8205435',
    },
  },
]

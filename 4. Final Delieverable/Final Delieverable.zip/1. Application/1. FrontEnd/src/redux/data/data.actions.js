export const fetchListing = (payload) => ({
  type: 'FETCH_LISTING',
  payload,
})
